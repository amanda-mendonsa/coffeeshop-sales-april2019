SELECT SUM(line_item_amount) AS total_sales
FROM `coffe shop sales`;