SELECT sales_outlet_id,
SUM(line_item_amount) AS RegionOutlet_sales
FROM `coffe shop sales`
GROUP BY sales_outlet_id
ORDER BY sales_outlet_id  ASC;
