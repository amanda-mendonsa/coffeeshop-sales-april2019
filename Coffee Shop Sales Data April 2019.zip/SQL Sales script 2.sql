SELECT
transaction_id
,transaction_date
,transaction_time
,line_item_amount
,line_item_id
,STR_TO_DATE(CONCAT(transaction_date, ' ', transaction_time), '%Y-%m-%d %H:%i:%s') AS combined_datetime
,SUM(line_item_amount) AS total_sales
FROM sales_reciepts.`coffe shop sales`
GROUP BY transaction_id
,transaction_date
,transaction_time
,line_item_amount
,line_item_id
ORDER BY transaction_date
